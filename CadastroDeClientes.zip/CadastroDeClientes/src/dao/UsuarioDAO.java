
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Usuario;
import view.Cadastro;

/**
 *
 * @author Paulo
 */
public class UsuarioDAO {
    
    private final Connection connection;

    public UsuarioDAO(Connection connection) {
        this.connection = connection;
    }

    
    public void insert(Usuario nome) throws SQLException{         
            
            String sql = "insert into usuario(nome,senha,cpf) values('"+nome.getNome() +"','"+ nome.getSenha() +"','"+nome.getCpf()+"');";            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();            
                  
                    
    }

    public boolean confirmarNomeSenha(Usuario confirmarUsuario) throws SQLException {
        String sql = "select * from nome where nome = '"+confirmarUsuario.getNome()+"' and senha + '"+confirmarUsuario.getSenha()+"'";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.execute();
        ResultSet resultSet = statement.getResultSet();
        return resultSet.next();
    }

    
    
}
