
package Controlador;

import dao.Conexão;
import dao.UsuarioDAO;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Usuario;
import view.Login;
import view.menu;

/**
 *
 * @author Paulo
 */
public class FormLogin {
    private Login view;

    public FormLogin(Login view) {
        this.view = view;
    }

    public void confirmaçao() throws SQLException {
        
        String nome = view.getTxtNome().getText();
        String senha = view.getTxtSenha().getText();
        String cpf = null;
        
        Usuario confirmarUsuario = new Usuario(nome,senha,cpf);
        
        Connection conexao = new Conexão().getConnection();
        UsuarioDAO usuarioDao = new UsuarioDAO(conexao);
        
        boolean existe = usuarioDao.confirmarNomeSenha(confirmarUsuario);            
        
        
        if(existe){
        menu páginaMenu = new menu();
        páginaMenu.setVisible(true);
        }   
        else{
            JOptionPane.showMessageDialog(view, "Usuário ou senha inválidos");
        }
        }

    
}
